# paymentsapi-quickstart

## Overview
This sample demonstrates basic usage of the Google Payment API.  For more
information, visit the following link:

https://developers.google.com/payments/overview

## Instructions

Make sure you read the comments in Constants.java and PaymentsUtil.java before
you continue. These files **must** be modified prior to running the app, as per
the instructions provided in the comments.
